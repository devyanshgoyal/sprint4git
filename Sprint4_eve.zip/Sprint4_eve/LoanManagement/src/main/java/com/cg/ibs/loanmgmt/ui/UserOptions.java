package com.cg.ibs.loanmgmt.ui;

public enum UserOptions {
	EXISTING_CUSTOMER, BANK_ADMIN, VISITOR, EXIT
}
