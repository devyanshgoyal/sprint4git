package com.cg.ibs.loanmgmt.dao;

import javax.persistence.EntityManager;

import com.cg.ibs.loanmgmt.bean.LoanTypeBean;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class LoanTypeDaoImpl implements LoanTypeDao{
	private LoanTypeBean loanTypeBean;
	private EntityManager entityManager;
	
	public LoanTypeDaoImpl() {
		entityManager = JpaUtil.getEntityManger();
	}

	@Override
	public LoanTypeBean getLoanType(Integer typeId) {
		loanTypeBean = entityManager.find(LoanTypeBean.class,typeId);
		return loanTypeBean;
	}
}