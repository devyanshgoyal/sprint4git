package com.cg.ibs.loanmgmt.dao;

public class BankAdminsDaoImpl implements BankAdminsDao{

}
