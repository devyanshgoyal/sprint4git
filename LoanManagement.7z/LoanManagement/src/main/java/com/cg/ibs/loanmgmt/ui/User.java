package com.cg.ibs.loanmgmt.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ibs.loanmgmt.IBSexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.IBSexception.IBSException;
import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.service.CustomerService;
import com.cg.ibs.loanmgmt.service.CustomerServiceImpl;

public class User implements ExceptionMessages {
	private static CustomerService customerService = new CustomerServiceImpl();
	private static Scanner read = new Scanner(System.in);
	private CustomerBean client;
	private LoanMaster loan;

	public void userLogin() throws IBSException {
		UserOptions choice = null;

		while (choice != UserOptions.EXIT) {
			System.out.println("Login as an existing customer or admin? ");
			System.out.println("------------------------");
			for (UserOptions menu : UserOptions.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			String userLoginInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1}");
			Matcher matcher = pattern.matcher(userLoginInput);
			if (matcher.matches()) {
				int ordinal = Integer.parseInt(userLoginInput);
				if (ordinal >= 1 && ordinal < (UserOptions.values().length) + 1) {
					choice = UserOptions.values()[ordinal - 1];
					switch (choice) {
					case VISITOR:
						loan = selectLoanType();
						applyLoan(callingCustomerLogin(),loan);
						break;
					case EXISTING_CUSTOMER:
						init(customerLogin());
						break;
					case BANK_ADMIN:
						break;
					case EXIT:
						System.out.println("\nThank You For Visiting. \nHave a nice day!");
						break;
					}
				} else {
					choice = null;
					try {
						if (choice == null) {
							throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
						}
					} catch (IBSException exp) {
//						LOGGER.info("User is giving wrong input");
						System.out.println(exp.getMessage());

					}

				}
			} else {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORINPUTMISMATCH);
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());
				}
			}
		}
	}

	private LoanMaster selectLoanType() throws IBSException {
		LoanTypes choice = null;
		LoanMaster loanMaster = null;
		while (choice != LoanTypes.GO_BACK) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (LoanTypes menu : LoanTypes.values()) {
				System.out.println((menu.ordinal() + 1) + "\t" + menu);
			}
			System.out.println("Choice");
			String customerLoginInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1}");
			Matcher matcher = pattern.matcher(customerLoginInput);
			if (matcher.matches()) {
				int ordinal = Integer.parseInt(customerLoginInput);
				if (ordinal >= 1 && ordinal < (LoanTypes.values().length) + 1) {
					choice = LoanTypes.values()[ordinal - 1];

					switch (choice) {
					case HOME_LOAN:
						loanMaster = calculateEMI(1);
						break;
					case EDUCATION_LOAN:
						loanMaster = calculateEMI(2);
						break;
					case PERSONAL_LOAN:
						loanMaster = calculateEMI(3);
						break;
					case VEHICLE_LOAN:
						loanMaster = calculateEMI(4);
						break;
					case GO_BACK:
						System.out.println("Thank You!");
						break;
					}
				} else {
					choice = null;
					try {
						if (choice == null) {
							throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
						}
					} catch (IBSException exp) {
						System.out.println(exp.getMessage());

					}
				}

			} else {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORINPUTMISMATCH);
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());
				}
			}

		}
		return loanMaster;
	}

	public CustomerBean init(CustomerBean customer) throws IBSException {
		CustomerOptions customerChoice = null;
		System.out.println("Welcome " + customer.getFirstName() + " " + customer.getLastName());
		while (customerChoice != CustomerOptions.LOG_OUT) {
			System.out.println("--------------------");
			System.out.println("Please select one of the following to proceed further : ");
			System.out.println("--------------------");
			for (CustomerOptions menu : CustomerOptions.values()) {
				System.out.println((menu.ordinal() + 1) + ".\t" + menu);
			}
			System.out.println("Choice");
			String customerLoginInput = read.next();
			Pattern pattern = Pattern.compile("[0-9]{1}");
			Matcher matcher = pattern.matcher(customerLoginInput);
			if (matcher.matches()) {
				int ordinal = Integer.parseInt(customerLoginInput);
				if (ordinal >= 1 && ordinal < (CustomerOptions.values().length) + 1) {
					customerChoice = CustomerOptions.values()[ordinal - 1];
					switch (customerChoice) {
					case APPLY_LOAN:
						applyLoan(customer, selectLoanType());
						break;
					case PAY_EMI:

						break;
					case APPLY_PRECLOSURE:

						break;
					case VIEW_HISTORY:

						break;
					case LOG_OUT:
						System.out.println("Thank You! Come Again.");
						userLogin();
					}

				} else {
					customerChoice = null;
					try {
						if (customerChoice == null)

							throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
					} catch (IBSException exp) {
						System.out.println(exp.getMessage());
					}
				}
			} else {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORINPUTMISMATCH);
				} catch (IBSException exp) {
					System.out.println(exp.getMessage());
				}
			}
		}
		return customer;
	}

	// customer Login
	private CustomerBean customerLogin() {
		CustomerBean customerLoggedIn = new CustomerBean();
		boolean shallContinue = true;
		String userId = "";
		while (shallContinue) {
			System.out.println("Login with your Registered UserID");
			System.out.println("UserID: ");
			userId = read.next();
			System.out.println("Password: ");
			String password = read.next();
			shallContinue = !customerService.verifyCustomerLogin(userId, password);
			if (shallContinue) {
				System.out.println("**##Not a Registered Customer##**");
			}
			else {
				System.out.println("Logged In");
			}
		}
		if(!shallContinue) {
			customerLoggedIn=customerService.getCustomer(userId);
		}
		return customerLoggedIn;
	}

	private void applyLoan(CustomerBean customer, LoanMaster loanMaster) {
	callingCustomerLogin();
	System.out.println("Hello you're in ");
	}

	// customer Login for Customer
	private CustomerBean callingCustomerLogin() {
		System.out.println("Do you want to apply for this loan");
		Integer input = read.nextInt();
		switch (input) {
		case 1:
			client = customerLogin();
		case 2:
			System.out.println("Thank You for visiting");
		}
		return client;

	}

	// EMI Calculation for Visitor/Customer
	private LoanMaster calculateEMI(Integer typeId) {
		LoanMaster loanMaster = new LoanMaster();
		loanMaster.setTypeId(typeId);
		System.out.println("-----------------------------------------\n");
		System.out.println("Loan Type:\t" + customerService.getLoanType(loanMaster.getTypeId()).getLoanType());
		System.out.println("Interest Rate:\t" + customerService.getLoanType(loanMaster.getTypeId()).getInterestRate());
		System.out.println(
				"Maximum Loan Amount:\t" + customerService.getLoanType(loanMaster.getTypeId()).getMaximumLimit());
		System.out.println(
				"Minimum Loan Amount:\t" + customerService.getLoanType(loanMaster.getTypeId()).getMinimumLimit());
		boolean shallContinue = true;
		while (shallContinue) {
			System.out.println("Enter Loan Amount: ");
			loanMaster.setLoanAmount(read.nextBigDecimal());
			shallContinue = !customerService.verifyLoanAmount(loanMaster.getLoanAmount(),
					customerService.getLoanType(loanMaster.getTypeId()).getMaximumLimit(),
					customerService.getLoanType(loanMaster.getTypeId()).getMinimumLimit());
			if (shallContinue) {
				System.out.println("**##Please Adhere to the Loan Limits Specified!##**");
			}
		}
		shallContinue = true;
		while (shallContinue) {
			System.out.println("Enter Loan Tenure (Months): ");
			System.out.println("\t** Tenure should in multiples of 6 months **");
			loanMaster.setLoanTenure(read.nextInt());
			shallContinue = !customerService.verifyLoanTenure(loanMaster.getLoanTenure());
			if (shallContinue) {
				System.out.println("**##Please Adhere to the Loan Tenure limits Specified!##**");
			}
		}
		customerService.calculateEmi(loanMaster);
		System.out.println("Monthly EMI:\t" + loanMaster.getEmiAmount().toPlainString());
	
		return loanMaster;
	}

	public static void main(String[] args) throws IBSException {
		User user = new User();
		user.userLogin();
	}
}
