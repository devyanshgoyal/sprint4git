package com.cg.ibs.loanmgmt.dao;

import com.cg.ibs.loanmgmt.bean.CustomerBean;

public interface CustomerDao {
	CustomerBean getCustomerByUserId(String userId);
}
