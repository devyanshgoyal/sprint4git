package com.cg.ibs.loanmgmt.dao;

public interface BankAdminsDao {

}
