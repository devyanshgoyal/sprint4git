package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;

public interface CustomerService {
	LoanTypeBean getLoanType(Integer typeId);

	boolean verifyLoanAmount(BigDecimal loanAmount, BigDecimal maximumLimit, BigDecimal minimumLimit);

	public boolean verifyLoanTenure(int tenure);
	
	LoanMaster calculateEmi(LoanMaster loanMaster);
	
	boolean verifyCustomerLogin(String userId, String password);
	CustomerBean getCustomer(String userId);
}
