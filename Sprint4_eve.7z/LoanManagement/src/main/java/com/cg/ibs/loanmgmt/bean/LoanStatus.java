package com.cg.ibs.loanmgmt.bean;

public enum LoanStatus {
	PENDING, APPROVED, DENIED, PRE_CLOSURE_VERIFICATION, CLOSED;

}
