package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;

public interface CustomerService {
	LoanTypeBean getLoanTypeByTypeId(Integer typeId);

	boolean verifyLoanAmount(BigDecimal loanAmount, BigDecimal maximumLimit, BigDecimal minimumLimit);

	public boolean verifyLoanTenure(int tenure);

	LoanMaster calculateEmi(LoanMaster loanMaster);

	boolean verifyCustomerLogin(String userId, String password);
	
	LoanMaster applyLoan(CustomerBean customer,LoanMaster loanMaster, String path);

	CustomerBean getCustomer(String userId);

	List<LoanMaster> getLoanListByUci(CustomerBean customer);
	
	
}
